package com.example.job_hop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
