import 'package:google_fonts/google_fonts.dart';
import 'package:flutter/material.dart';
import 'package:job_hop/Screens/Sidebar.dart';

import 'joboffer.dart';

class Jobview extends StatefulWidget {
  const Jobview({super.key});

  @override
  State<Jobview> createState() => _JobviewState();
}

class _JobviewState extends State<Jobview> {
  final myProducts = List<String>.generate(100, (i) => 'Product $i');
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const Side(),
      body: CustomScrollView(
        slivers: <Widget>[
          SliverAppBar(
            pinned: true,
            snap: false,
            floating: true,
            expandedHeight: 150.0,
            flexibleSpace: FlexibleSpaceBar(
              title: Container(
                width: 300,
                child: Text(
                  'Job Hop',
                  style: GoogleFonts.monoton(
                      textStyle: Theme.of(context).textTheme.headline4,
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      fontStyle: FontStyle.italic,
                      color: Colors.black),
                ),
              ),
              // background: Image.asset(
              //   'assets/images/beach.png',
              //   fit: BoxFit.fill,
              // ),
            ),
          ),
          //3
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (BuildContext context, int index) {
                return Card(
                  elevation: 10,
                  margin:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        color: Colors.blue[100 * (index % 9 + 1)],
                        height: 50,
                        width: 50,
                        child: const Icon(
                          Icons.search_off_rounded,
                        ),
                      ),
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            // ignore: prefer_const_literals_to_create_immutables
                            children: [
                              const Padding(
                                padding: EdgeInsets.only(left: 3, right: 8),
                                child: Text(
                                  'Company Name',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              const Padding(
                                padding: EdgeInsets.only(left: 3, right: 8),
                                child: Text(
                                  'Job Title',
                                  style: TextStyle(
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: Colors.blue[100 * (index % 9 + 1)],
                          ),
                          height: 30,
                          child: TextButton(
                            child: const Text(
                              'View',
                              style: TextStyle(
                                color: Color.fromARGB(255, 0, 0, 0),
                              ),
                            ),
                            onPressed: () {
                              print('View  pressed');
                              // print(nameController.text);
                              // print(passwordController.text);
                              // Navigator.pushAndRemoveUntil(context,
                              //     MaterialPageRoute(builder: (BuildContext context) {
                              //   return Jobview();
                              // }), (r) {
                              //   return false;
                              // });
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
              childCount: 1000, // 1000 list items
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.pushAndRemoveUntil(context,
              MaterialPageRoute(builder: (BuildContext context) {
            return const Joboffer();
          }), (r) {
            return false;
          });
        },
        label: const Text('Create New Job Offer'),
      ),
    );
  }
}
