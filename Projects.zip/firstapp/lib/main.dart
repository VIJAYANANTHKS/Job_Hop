import 'package:flutter/material.dart';

void main() {
  runApp(Hello());
}

class Hello extends StatefulWidget {
  const Hello({super.key});

  @override
  State<Hello> createState() => _HelloState();
}

class _HelloState extends State<Hello> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Example'),
          centerTitle: true,
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              width: 200,
              height: 150,
              decoration: BoxDecoration(
                  color: Colors.amber,
                  borderRadius: BorderRadius.circular(15.0)),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(
                          children: [
                            Container(
                              width: 50,
                              height: 40,
                              decoration: BoxDecoration(
                                  color: Colors.pink,
                                  borderRadius: BorderRadius.circular(15.0),
                                  border: Border.all(
                                      color: Colors.black, width: 2.0)),
                              child: Center(child: Text('Vijay')),
                            ),
                          ],
                        ),
                        Container(
                          width: 50,
                          height: 40,
                          decoration: BoxDecoration(
                              color: Colors.pink,
                              borderRadius: BorderRadius.circular(15.0),
                              border:
                                  Border.all(color: Colors.black, width: 2.0)),
                          child: Center(child: Text('Hello')),
                        )
                      ],
                    ),
                  ),
                  Row(
                    children: [
                      Column(
                        children: [],
                      )
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(
                      'Text 1',
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Text('Text 1')
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
