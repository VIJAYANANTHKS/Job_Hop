import 'package:flutter/material.dart';

void main() {
  runApp(one());
}

class one extends StatefulWidget {
  const one({super.key});

  @override
  State<one> createState() => _oneState();
}

class _oneState extends State<one> {
  @override
  bool on = true;

  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
      appBar: AppBar(title: Center(child: Text('Design 1'))),
      body: Center(
          child: Container(
        width: 300,
        height: 200,
        child: Row(
          children: <Widget>[
            Image(
                image: NetworkImage(
                    'https://cdn-images-1.medium.com/max/1200/1*5-aoK8IBmXve5whBQM90GA.png'))
          ],
        ),
      )),
    ));
  }
}
