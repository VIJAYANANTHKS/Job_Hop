import 'package:flutter/material.dart';

void main() {
  runApp(const Scr());
}

class Scr extends StatefulWidget {
  const Scr({super.key});

  @override
  State<Scr> createState() => _ScrState();
}

class _ScrState extends State<Scr> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          appBar: AppBar(
            title: Container(
                child: Row(
              children: const <Widget>[
                Icon(Icons.menu),
                Spacer(
                  flex: 1,
                ),
                Center(child: Text('Screen 1')),
                Spacer(
                  flex: 1,
                ),
                Icon(Icons.login_rounded)
              ],
            )),
          ),
          body: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: 1000,
              height: 1000,
              decoration: BoxDecoration(
                  color: Color.fromARGB(255, 173, 178, 180),
                  borderRadius: BorderRadius.circular(20.0)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                      height: 45,
                      width: 50,
                      decoration: BoxDecoration(
                          color: Color.fromARGB(255, 241, 224, 230),
                          borderRadius: BorderRadius.circular(20.0)),
                      child: ListView.builder(
                        itemCount: 20,
                        itemBuilder: (context, index) {
                          return Container(
                            child: IconButton(
                                onPressed: () {
                                  print('Button Clicked');
                                },
                                icon: Icon(Icons.mail)),
                          );
                        },
                      ))
                ],
              ),
            ),
          ),
          bottomNavigationBar: BottomNavigationBar(
            items: const <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                  icon: Icon(Icons.home),
                  label: 'Home',
                  backgroundColor: Colors.green),
              BottomNavigationBarItem(
                  icon: Icon(Icons.search),
                  label: 'Search',
                  backgroundColor: Colors.yellow),
              BottomNavigationBarItem(
                icon: Icon(Icons.person),
                label: 'Profile',
                backgroundColor: Colors.blue,
              ),
            ],
          ),
        ));
  }
}
