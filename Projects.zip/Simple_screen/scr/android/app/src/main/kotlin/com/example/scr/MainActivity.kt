package com.example.scr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
